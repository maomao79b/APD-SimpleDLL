﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleDLL2
{
    public class Simple2
    {
        public double AreaCircle(int radius)
        {
            return Math.PI * radius * radius;
        }
    }
}
